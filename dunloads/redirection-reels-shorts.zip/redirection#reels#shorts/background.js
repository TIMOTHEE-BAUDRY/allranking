chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete') {
      if (tab.url.includes("https://www.instagram.com/reels/")) {
        setTimeout(() => {
          chrome.tabs.update(tabId, { url: "https://timothee-baudry.github.io/allranking/" });//rediriger vers n'importe quelle page
        }, 100); 
      } else if (tab.url.includes("https://www.youtube.com/shorts/")) {
        setTimeout(() => {
          chrome.tabs.update(tabId, { url: "https://timothee-baudry.github.io/allranking/" });//rediriger vers n'importe quelle page
        }, 100);
      }
    }
  });
  
